# CSGO-Case-Clicker
A website-based CSGO case clicker

This is the source for the CSGO Clicker you know and love. Please expand on to it if you want. Would love to see what you guys can make for it.

Add me on Discord @ KingofKFCJamal#6900 or on Steam @ https://steamcommunity.com/id/KingofKFC/ if you need anything or want to ask questions. Thanks and have fun.
